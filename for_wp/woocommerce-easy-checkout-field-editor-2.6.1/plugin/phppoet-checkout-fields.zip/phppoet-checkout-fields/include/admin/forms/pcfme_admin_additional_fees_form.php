<?php
    $additional_fees    = $this->additional_fees;
    $additional_fees    = array_filter($additional_fees);
    $country_fields     = 'shipping_country,shipping_state,billing_country,billing_state,billing_city,shipping_city';

    
?>
<table class="widefat pcfme-fees-table">
    <?php

        foreach ($additional_fees as $key => $value) { 
            $mnindex = $key + 1;


        	?>

        	


        	<tr class="conditional-row conditional-row-<?php echo $mnindex; ?>">
        		<td>
        			<strong><?php echo esc_html__( 'Add' ,'pcfme'); ?></strong>
        		</td>
        		<td>
        			<input type="number" name="pcfme_additional_fees[<?php echo $mnindex; ?>][amount]" value="<?php if (isset($value['amount']) ) { echo $value['amount']; } ?>" placeholder="<?php echo esc_html__( 'Amount' ,'pcfme'); ?>">
        		</td>
        		<td>
        			<span class="pcfmeformfield">
        				<strong><?php echo esc_html__( 'If Value of' ,'pcfme'); ?></strong>
        			</span>
        		</td>
        		<td>
        			<select class="checkout_field_rule_parentfield" name="pcfme_additional_fees[<?php echo $mnindex; ?>][parentfield]">
        				
        					
        				<optgroup label="<?php echo esc_html__( 'Billing Fields' ,'pcfme'); ?>">
        					<?php
        					foreach ($this->billing_settings as $optionkey=>$optionvalue) { 

        						if ( (isset ($optionvalue['type']) && ($optionvalue['type'] == 'email')) || (preg_match('/\b'.$optionkey.'\b/', $country_fields ))) { 

        						} else { 

        							if (isset($optionvalue['label']))  { 

        								$optionlabel = $optionvalue['label']; 

        							} else { 

        								$optionlabel = $optionkey; 
        							}
        							?> 

        							<option value="<?php echo $optionkey; ?>" <?php if (isset($value['parentfield']) && ($value['parentfield'] == $optionkey)) { echo 'selected';} ?>>
        								<?php echo $optionlabel; ?>
        									
        							</option>

        							<?php
        							
        						} 
        					} 
        					?>
        				</optgroup>

        				<optgroup label="<?php echo esc_html__( 'Shipping Fields' ,'pcfme'); ?>">
        					<?php
        					foreach ($this->shipping_settings as $optionkey=>$optionvalue) { 

        						if ( (isset ($optionvalue['type']) && ($optionvalue['type'] == 'email')) || (preg_match('/\b'.$optionkey.'\b/', $country_fields ))) { 

        						} else { 

        							if (isset($optionvalue['label']))  { 

        								$optionlabel = $optionvalue['label']; 

        							} else { 

        								$optionlabel = $optionkey; 
        							}
        							?> 

        							<option value="<?php echo $optionkey; ?>" <?php if (isset($value['parentfield']) && ($value['parentfield'] == $optionkey)) { echo 'selected';} ?>>
        								<?php echo $optionlabel; ?>
        									
        							</option>

        							<?php
        							
        						} 
        					} 
        					?>
        				</optgroup>

                        <?php

                        $additional_settings  = $this->additional_settings;
                        $additional_settings  = array_filter($additional_settings);

                        if (isset($additional_settings) && (sizeof($additional_settings) >= 1)) { 
                            $conditional_fields_dropdown = $additional_settings;
                        } else {
                            $conditional_fields_dropdown = array();
                        }




                        if (count($conditional_fields_dropdown) != 0) { ?>

                                <optgroup label="<?php echo esc_html__( 'Additional Fields' ,'pcfme'); ?>">

                        <?php 

                        


        					foreach ($conditional_fields_dropdown as $optionkey=>$optionvalue) { 

        						if ( (isset ($optionvalue['type']) && ($optionvalue['type'] == 'email')) || (preg_match('/\b'.$optionkey.'\b/', $country_fields ))) { 

        						} else { 

        							if (isset($optionvalue['label']))  { 

        								$optionlabel = $optionvalue['label']; 

        							} else { 

        								$optionlabel = $optionkey; 
        							}
        							?> 

        							<option value="<?php echo $optionkey; ?>" <?php if (isset($value['parentfield']) && ($value['parentfield'] == $optionkey)) { echo 'selected';} ?>>
        								<?php echo $optionlabel; ?>
        									
        							</option>

        							<?php
        							
        						} 
        					} 
        				

        				
                         ?>

                                </optgroup>

                        <?php } ?>
        				

        			</select>
        		</td>
        		<td>
        			<span class="pcfmeformfield"><strong><?php echo esc_html__( 'is equal to' ,'pcfme'); ?></strong></span>
        		</td>
        		<td>
        			<input type="text" class="checkout_field_conditional_equalto" name="pcfme_additional_fees[<?php echo $mnindex; ?>][equalto]" value="<?php if (isset($value['equalto']) ) { echo $value['equalto']; } ?>">
        		</td>
        		<td>
        			<span class="glyphicon glyphicon-trash pcfme-remove-rule"></span>
        		</td>

        	</tr>


        <?php 

                $mnindex++;
            }

    ?>
    
</table>
<table>
	<tr>
    	<td width="100%">
    		<ul class="rules_explain_ul">
    			<li>
    				<?php echo esc_html__('If field is checkbox leave blank for equal to field.','pcfme'); ?>
    			</li>
    			<li>
    				<?php echo esc_html__('If field is radio/select and its value has space, replace space with underscore ( _ ) for example equal to field for "Option 3" will be Option_3.','pcfme'); ?>
    			</li>
    			<li>
    				<?php echo esc_html__('You can also use text/textarea field as field.','pcfme'); ?>
    			</li>
    		</ul>
    	</td>
    </tr>
</table>
<button type="button" mnindex="<?php if (isset($mnindex)) { echo $mnindex; } else { echo 1;} ?>" class="btn button-primary add-fees-button">
	<span class="dashicons dashicons-insert add_rule_icon"></span>
	<?php echo esc_html__( 'Add Fees Rule' ,'pcfme'); ?>
</button>